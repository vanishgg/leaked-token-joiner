import os
import sys
import yaml
import time
import httpx
import string
import base64
import random
import requests
import colorama
import datetime
import tls_client
from colorama import init
from datetime import datetime
from colorama import Fore, Style
from concurrent.futures import ThreadPoolExecutor
init()
with open('config.yaml') as f:
    config = yaml.safe_load(f)
    config = config["config"]["data"]
try:
    server_inv = str(input(f'{Fore.GREEN}[?] {Fore.MAGENTA}- {Fore.WHITE}Enter Guild Invite - '))
    useproxy = config["proxy-supp"]["use-proxy"]
    proxy = config["proxy-supp"]["proxy"]
    cb = config["custom-branding"]["use-custom-branding"]
    name = config["custom-branding"]["display-name"]
except:
    print("Failed to read config... Exiting in 20 seconds...")
    time.sleep(20)
    sys.exit(0)

def get_fingerprint():
    try:
        fingerprint = httpx.get(f"https://discord.com/api/v10/experiments")
        return fingerprint.json()['fingerprint']
    except Exception as e:
        return get_fingerprint()

class Logger:
    @staticmethod
    def stamp():
        return datetime.now().strftime('%H:%M:%S') + ';' + datetime.now().strftime('%Y-%m-%d')
  
    @staticmethod
    def stamp2():
        return datetime.now().strftime('%H:%M:%S')
  
    @staticmethod
    def success(file, content:str):
        fullt = Logger.stamp()
        time = fullt.split(';')[1]
        day = fullt.split(';')[0]
        print(f'{Style.BRIGHT}{Fore.BLACK}{time} ◦ {Fore.GREEN}DBG{Fore.BLACK} ◦ {day} ◦ {file} >>    {content}{Fore.RESET}{Style.RESET_ALL}')
  
    @staticmethod
    def remove_content(filename: str, delete_line: str):
        with open(filename, "r+") as io:
            content = io.readlines()
            io.seek(0)
            for line in content:
                if not (delete_line in line):
                    io.write(line)
            io.truncate()
  
    @staticmethod
    def mainsuc(content:str):
        fullt = Logger.stamp()
        time = fullt.split(';')[1]
        day = fullt.split(';')[0]
        print(f'{Style.BRIGHT}{Fore.BLACK}{time} ◦ {Fore.GREEN}INF{Fore.BLACK} ◦ {day} ◦ boost.py >>    {Fore.GREEN}{content}{Fore.RESET}{Style.RESET_ALL}')
  
    @staticmethod
    def error(file,content:str):
        fullt = Logger.stamp()
        time = fullt.split(';')[1]
        day = fullt.split(';')[0]
        print(f'{Style.BRIGHT}{Fore.BLACK}{time} ◦ {Fore.RED}ERR {Fore.BLACK}◦ {day} ◦ {file} >>    {Fore.RED}{content}{Fore.RESET}{Style.RESET_ALL}')

class Booster:
    def __init__(self, token: str):
        self.full = token
        self.times = 0
        if 'https://discord.gg/' in server_inv:
            self.invite = server_inv.replace('https://discord.gg/', '')
        
        elif 'discord.gg' in server_inv and not 'https' in server_inv:
            self.invite = server_inv.replace('discord.gg/','')
        elif not 'https://discord' in server_inv and '.gg' in server_inv:
            self.invite = server_inv.replace('.gg/', '')

        elif not 'https://discord' and '.gg/' in server_inv:
            self.invite = server_inv

        if '@' in token:
            self.token = token.split(':')[2]
        else:
            self.token = token

        if len(proxy.split(':')) == 2:
            Logger.error('proxy.py', 'This proxy type is not supported. Please use user:pass:@host:port, not ip:port')
            return
        else:
            pass
        self.session = tls_client.Session(
            client_identifier="chrome_109",
            random_tls_extension_order=True
        )
        self.session2 = tls_client.Session(
            client_identifier="chrome_109",
            random_tls_extension_order=True
        )
        if useproxy:
            self.session.proxies = {'https': 'http://'+proxy}
            self.session2.proxies ={'https': 'http://'+proxy}
        else:
            self.session.proxies = None
            self.session2.proxies = None

    def obt_cookies(self):
        cookies = {}
        try:
            response = self.session.get('https://discord.com')
            for cookie in response.cookies:
                if cookie.name.startswith('__') and cookie.name.endswith('uid'):
                    cookies[cookie.name] = cookie.value
            return cookies
        except Exception as e:
            Logger.error('cookie.py', f'Failed to obtain cookies, exception: {e}')
            return {}

    def joiner(self):
        self.headers = {
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9',
            'authorization': self.token,
            'content-type': 'application/json',
            'origin': 'https://discord.com',
            'referer': 'https://discord.com/channels/@me',
            'sec-ch-ua': '"Microsoft Edge";v="123", "Not:A-Brand";v="8", "Chromium";v="123"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0',
            'x-context-properties': 'eyJsb2NhdGlvbiI6Ikludml0ZSBCdXR0b24gRW1iZWQiLCJsb2NhdGlvbl9ndWlsZF9pZCI6bnVsbCwibG9jYXRpb25fY2hhbm5lbF9pZCI6IjEyMDk4MjYwMDAzNTIwNTk0MDMiLCJsb2NhdGlvbl9jaGFubmVsX3R5cGUiOjEsImxvY2F0aW9uX21lc3NhZ2VfaWQiOiIxMjIzNjE2NDEyMDQwNTYwNjcwIn0=',
            'x-debug-options': 'bugReporterEnabled',
            'x-discord-locale': 'en-US',
            'x-discord-timezone': 'Europe/Budapest',
            'x-super-properties': 'eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiQ2hyb21lIiwiZGV2aWNlIjoiIiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEyMy4wLjAuMCBTYWZhcmkvNTM3LjM2IEVkZy8xMjMuMC4wLjAiLCJicm93c2VyX3ZlcnNpb24iOiIxMjMuMC4wLjAiLCJvc192ZXJzaW9uIjoiMTAiLCJyZWZlcnJlciI6Imh0dHBzOi8vZGlzY29yZC5jb20vP2Rpc2NvcmR0b2tlbj1NVEEzTURReU56RXhNVGM1TVRJNE5ESTROQS5HYWNhYnIuVE9NZUVzbHdiczJ2OFRlck4wOTM3SzVvS0ZFMFZyZW5fdWF6Q1kiLCJyZWZlcnJpbmdfZG9tYWluIjoiZGlzY29yZC5jb20iLCJyZWZlcnJlcl9jdXJyZW50IjoiIiwicmVmZXJyaW5nX2RvbWFpbl9jdXJyZW50IjoiIiwicmVsZWFzZV9jaGFubmVsIjoic3RhYmxlIiwiY2xpZW50X2J1aWxkX251bWJlciI6MjgwMjMxLCJjbGllbnRfZXZlbnRfc291cmNlIjpudWxsfQ==',
        }
        try:
            response = self.session.post(f'https://discord.com/api/v9/invites/{self.invite}',
                                         headers=self.headers,
                                         json={'session_id': ''.join(random.choice(string.ascii_lowercase) + random.choice(string.digits) for _ in range(16))},
                                         cookies=self.obt_cookies())
        except Exception as e:
            Logger.error('joins.py', f'Failed to join server "{self.invite}" with {self.token[:23]}***.***, proxy error: {e}')
            with open('output/unhandled.txt', 'a') as f:
                f.write(self.full + '\n')
            return False

        if response.status_code in (200, 204):
            Logger.success('joins.py', 'Joined server "{}" successfully'.format(self.invite))
            self.guild = response.json()["guild"]["id"]
            return True
        elif response.status_code == 401:
            Logger.error('joins.py', f'Invalid token {self.token[:23]}***.***')
            with open('output/invalid_tokens.txt', 'a') as f:
                f.write(self.full + '\n')
            return False
        elif 'Unknown Invite' in response.json():
            Logger.error('joins.py', f'Failed to join server "{self.invite}", reason: invalid invite.')
            return False
        else:
            if 'captcha' in response.text:
                Logger.error('joins.py', f'Failed to join server {self.invite} with {self.token[:23]}***.***, captcha required.')
                with open('output/captcha_tokens.txt', 'a') as f:
                    f.write(self.full + '\n')
                return False
            else:
                Logger.error('joins.py', f'Failed to join server {self.invite} with {self.token[:23]}***.***, response: {response.json()}')
                with open('output/unhandled.txt', 'a') as f:
                    f.write(self.full + '\n')
                return False
            
    def put_boost(self) -> bool:  
     try:
        headers = {
            'accept': '*/*',
            'accept-encoding': 'gzip, deflate, br',
            'accept-language': 'en-US,en;q=0.9',
            'authorization': self.token,
            'content-type': 'application/json',
            'origin': 'https://discord.com',
            'referer': 'https://discord.com',
            'sec-ch-ua': f'"Google Chrome";v="108", "Chromium";v="108", "Not=A?Brand";v="8"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0',
            'x-context-properties': 'eyJsb2NhdGlvbiI6IkpvaW4gR3VpbGQiLCJsb2NhdGlvbl9ndWlsZF9pZCI6IjY3OTg3NTk0NjU5NzA1NjY4MyIsImxvY2F0aW9uX2NoYW5uZWxfaWQiOiIxMDM1ODkyMzI4ODg5NTk0MDM2IiwibG9jYXRpb25fY2hhbm5lbF90eXBlIjowfQ==',
            'x-debug-options': 'bugReporterEnabled',
            'x-discord-locale': 'en-US',
            'x-super-properties': 'eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiQ2hyb21lIiwiZGV2aWNlIjoiIiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEyMy4wLjAuMCBTYWZhcmkvNTM3LjM2IEVkZy8xMjMuMC4wLjAiLCJicm93c2VyX3ZlcnNpb24iOiIxMjMuMC4wLjAiLCJvc192ZXJzaW9uIjoiMTAiLCJyZWZlcnJlciI6Imh0dHBzOi8vZGlzY29yZC5jb20vP2Rpc2NvcmR0b2tlbj1NVEEzTURReU56RXhNVGM1TVRJNE5ESTROQS5HYWNhYnIuVE9NZUVzbHdiczJ2OFRlck4wOTM3SzVvS0ZFMFZyZW5fdWF6Q1kiLCJyZWZlcnJpbmdfZG9tYWluIjoiZGlzY29yZC5jb20iLCJyZWZlcnJlcl9jdXJyZW50IjoiIiwicmVmZXJyaW5nX2RvbWFpbl9jdXJyZW50IjoiIiwicmVsZWFzZV9jaGFubmVsIjoic3RhYmxlIiwiY2xpZW50X2J1aWxkX251bWJlciI6MjgwMjMxLCJjbGllbnRfZXZlbnRfc291cmNlIjpudWxsfQ==',
            'fingerprint': get_fingerprint()
        }
        
        boost_dat = self.session.get(f"https://discord.com/api/v9/users/@me/guilds/premium/subscription-slots", headers=headers, cookies=self.obt_cookies())
        if boost_dat.status_code == 200:
            boost_data = boost_dat.json()
            for boost in boost_data:
                boost_id = boost["id"]
                payload = {"user_premium_guild_subscription_slot_ids": [boost_id]}
                boosted = self.session.put(f"https://discord.com/api/v9/guilds/{self.guild}/premium/subscriptions", json=payload, headers=headers)
                if boosted.status_code == 201:
                    self.times += 1
                    Logger.mainsuc(f'Boosted server "{self.invite}" {self.times} time(s), token={Fore.GREEN}{self.token[:23]}***.**')
                    with open('output/main/boosted/boosted.txt', 'a') as f:
                        f.write(self.full+'\n')
                elif 'Must wait for premium server subscription cooldown to expire' in boosted.text:
                    Logger.error('serve.py', f'Failed to boost, reason: {Fore.YELLOW}insufficient boosts left.')
                    with open('output/main/boosting_error.txt', 'a') as f:
                        f.write(self.full+'\n')
                else:
                    Logger.error('serve.py', f'Failed to boost, reason: {Fore.YELLOW}{boosted.json()}')
                    with open('output/main/boosting_error.txt', 'a') as f:
                        f.write(self.full+'\n')
        else:
            Logger.error('serve.py', 'Failed to fetch boost data.')
     except Exception as e:
        Logger.error('serve.py', f'Error occurred: {e}')
   
    def water_mark(self) -> bool:
     if cb:
      wb = 0
          
      headers = {
    'authority': 'discord.com',
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9',
    'authorization': self.token,
    'content-type': 'application/json',
    'origin': 'https://discord.com',
    'referer': 'https://discord.com/channels/@me',
    'sec-ch-ua': '"Chromium";v="122", "Not(A:Brand";v="24", "Microsoft Edge";v="122"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0',
    'x-debug-options': 'bugReporterEnabled',
    'x-discord-locale': 'en-US',
    'x-discord-timezone': 'Europe/Budapest',
    'x-super-properties': 'eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiQ2hyb21lIiwiZGV2aWNlIjoiIiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzEyMi4wLjAuMCBTYWZhcmkvNTM3LjM2IEVkZy8xMjIuMC4wLjAiLCJicm93c2VyX3ZlcnNpb24iOiIxMjIuMC4wLjAiLCJvc192ZXJzaW9uIjoiMTAiLCJyZWZlcnJlciI6IiIsInJlZmVycmluZ19kb21haW4iOiIiLCJyZWZlcnJlcl9jdXJyZW50IjoiIiwicmVmZXJyaW5nX2RvbWFpbl9jdXJyZW50IjoiIiwicmVsZWFzZV9jaGFubmVsIjoic3RhYmxlIiwiY2xpZW50X2J1aWxkX251bWJlciI6Mjc2MDY0LCJjbGllbnRfZXZlbnRfc291cmNlIjpudWxsfQ==',
}
      json={
          'global_name': name
          }
      try:
          response=self.session.patch('https://discord.com/api/v9/users/@me',
                                      headers=headers,
                                      json=json)
      except Exception as e:
          print(e)
      if response.status_code in (200, 204):
          wb+=1
          Logger.success('serve.py',f'successfully watermarked {wb} time(s) [ DISPLAY NAME ]')
      else:
          Logger.error('serve.py', f'watermark serving failed [ DISPLAY-NAME ], water-marked times: {wb}')
     else:
         pass      
      


def process(token):
    instance = Booster(token)
    joinerBool = instance.joiner()
    instance.water_mark()

from colorama import init
init()
if __name__ == "__main__":
    bt = int(input(f'{Fore.GREEN}[?] {Fore.MAGENTA}- {Fore.WHITE}Enter Amount Of Tokens To Join - '))
    times = bt # Use integer division to ensure times is an integer
    
    threads = int(input(f'{Fore.GREEN}[?] {Fore.MAGENTA}- {Fore.WHITE}Enter Threads To Run - '))
    os.system('cls')  # Clear the console
    
    with ThreadPoolExecutor(max_workers=threads) as exc:
        with open('input/tokens.txt') as f:
            tokens = f.read().splitlines()[:times]  # Limit tokens to the times variable
            for token in tokens:
                exc.submit(process, token)

input("Press Enter to exit...")
